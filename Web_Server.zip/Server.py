#!/usr/bin/env python3
import time
import socket

header = b'''\
HTTP/1.1 200 OK\r\n\
Connection: keep-alive\r\n\
Content-Type: text/html\r\n\
Content-Length: 600\r\n\
\r\n\
''' 
data = bytes('Welcome', 'utf-8')

if __name__ == '__main__':
    server_address = ('127.0.0.1', 8000)
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
    server.bind(server_address)
    server.listen(5)
    while True:
        try:
            client, client_address = server.accept()
            with client:
                msg = client.recv(1024)
                filename = msg.split()[1][1:]
                print('\n MSG = ', msg, '\n')
                try:
                    f = open(filename)
                    outputdata = f.read()
                    data = bytes(outputdata, 'utf-8')
                    f.close()
                    print('Filename: ', filename)
                    # print("DATA: \n", outputdata)
                except Exception:
                    print("\n", filename, ' : File NOT FOUND')

                client.sendall(header + data)
                time.sleep(5)  # To Keep the socket open for a little longer.
                client.shutdown(socket.SHUT_RDWR)
        except KeyboardInterrupt:
            break

